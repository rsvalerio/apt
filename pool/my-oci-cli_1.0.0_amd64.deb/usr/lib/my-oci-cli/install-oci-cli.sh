#!/usr/bin/env bash
# Installs Oracle OCI CLI into /opt/oracle-cli via pip (no apt from postinst).
set -euo pipefail

readonly OCI=/usr/local/bin/oci
readonly INSTALL_DIR=/opt/oracle-cli

log() { echo "my-oci-cli: $*" >&2; }

if [[ -x $OCI ]] && "$OCI" --version &>/dev/null; then
	log "oci already installed at $OCI"
	exit 0
fi

if ! python3 -c 'import venv' 2>/dev/null; then
	log "python3-venv required (install python3-venv)"
	exit 1
fi

log "creating venv at $INSTALL_DIR"
rm -rf "$INSTALL_DIR"
python3 -m venv "$INSTALL_DIR"

log "installing oci-cli via pip (may take several minutes)..."
"$INSTALL_DIR/bin/pip" install --disable-pip-version-check --no-cache-dir oci-cli

ln -sf "$INSTALL_DIR/bin/oci" "$OCI"

[[ -x $OCI ]] || { log "$OCI missing after install"; exit 1; }
log "oci installed: $("$OCI" --version 2>&1 | head -n1)"

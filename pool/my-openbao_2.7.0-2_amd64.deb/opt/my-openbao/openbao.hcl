ui = true

# Public address clients reach this node at (Cloudflare → HAProxy on vm1 →
# the plaintext listener below); used for redirects and client-facing URLs.
api_addr = "https://bao.valeri.dev"

storage "postgresql" {
  # BAO_PG_CONNECTION_URL is exported by openbao-launch.sh from OCI Vault.
}

# OCI KMS Auto Unseal runs as an external plugin: built into bao up to 2.6.x
# (the plugin shadows it there), plugin-only from 2.7.0. It wraps the same
# go-kms-wrapping ocikms code, so it uses the same KMS key and ciphertext —
# switching is not a seal migration. The seal "ocikms" stanza itself (key id +
# endpoints from OCI Vault) is rendered by openbao-launch.sh at start.
plugin_directory = "/opt/my-openbao/plugins"

plugin "kms" "ocikms" {
  command = "openbao-plugin-kms-oci" # openbao-plugins kms-oci-v0.1.0, linux_amd64
  # Checked by bao before every exec, and by deb/Makefile at build time.
  sha256sum = "1d10812139a4a5f2fec52b9e18c3d1d3129fcea34fbab15bf6b7bbddd989f3e4"
}

listener "tcp" {
  address     = "127.0.0.1:8200"
  tls_disable = true
}

telemetry {
  prometheus_retention_time = "12h"
  disable_hostname          = true
}

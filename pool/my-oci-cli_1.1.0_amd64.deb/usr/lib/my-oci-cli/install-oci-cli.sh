#!/usr/bin/env bash
# Installs Oracle OCI CLI into /opt/oracle-cli via pip (no apt from postinst).
set -euo pipefail

readonly OCI=/usr/local/bin/oci
readonly INSTALL_DIR=/opt/oracle-cli
readonly OCI_REAL="$INSTALL_DIR/bin/oci"

log() { echo "my-oci-cli: $*" >&2; }

ensure_oci_wrapper() {
	cat >"$OCI" <<'EOF'
#!/usr/bin/env bash
set -euo pipefail
readonly OCI_REAL=/opt/oracle-cli/bin/oci
readonly INSTALLER=/usr/lib/my-oci-cli/install-oci-cli.sh
if [[ ! -x $OCI_REAL ]]; then
	"$INSTALLER"
fi
exec "$OCI_REAL" "$@"
EOF
	chmod 755 "$OCI"
}

ensure_oci_wrapper

if [[ -x $OCI_REAL ]] && "$OCI_REAL" --version &>/dev/null; then
	log "oci already installed at $OCI_REAL"
	exit 0
fi

if ! python3 -c 'import venv' 2>/dev/null; then
	log "python3-venv required (install python3-venv)"
	exit 1
fi

log "creating venv at $INSTALL_DIR"
rm -rf "$INSTALL_DIR"
python3 -m venv "$INSTALL_DIR"

log "installing oci-cli via pip (may take several minutes)..."
# In packaging tests /tmp is tmpfs; keep pip temp files on disk to avoid OOM kills.
tmpdir="${TMPDIR:-/var/tmp/my-oci-cli}"
mkdir -p "$tmpdir"
export TMPDIR="$tmpdir"
pip=("$INSTALL_DIR/bin/pip" install --disable-pip-version-check --no-cache-dir --prefer-binary --no-compile)
# Split heavy dependency installation to keep peak memory lower on small hosts.
"${pip[@]}" oci
"${pip[@]}" oci-cli

[[ -x $OCI_REAL ]] || { log "$OCI_REAL missing after install"; exit 1; }
log "oci installed: $("$OCI_REAL" --version 2>&1 | head -n1)"

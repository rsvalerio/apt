#!/usr/bin/env bash
# Regenerate haproxy.cfg from haproxy-sites.json when present, then validate.
set -euo pipefail

HAPROXY_SITES_JSON="${HAPROXY_SITES_JSON:-/etc/haproxy/haproxy-sites.json}"
HAPROXY_CONFIG="${HAPROXY_CONFIG:-/etc/haproxy/haproxy.cfg}"
GEN="/usr/local/sbin/gen-haproxy-config.sh"

if [[ -f "$HAPROXY_SITES_JSON" ]]; then
  "$GEN" all
fi

if [[ ! -f "$HAPROXY_CONFIG" ]]; then
  echo "ensure-haproxy-config: missing $HAPROXY_CONFIG" >&2
  exit 1
fi

exec haproxy -c -f "$HAPROXY_CONFIG"

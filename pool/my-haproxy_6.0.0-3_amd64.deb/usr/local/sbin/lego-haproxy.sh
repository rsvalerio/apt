#!/usr/bin/env bash
# lego-haproxy.sh
#
# Issue TLS certificates via lego (ACME) with DNS-01 (Cloudflare) and sync them into
# HAProxy's crt-list under /etc/haproxy/certs/, then reload HAProxy.
#
# Cloudflare credentials: CF_DNS_API_TOKEN is set by calling the lego binary through
# /usr/local/sbin/lego-haproxy-launch.sh (get_secret + exec lego).
#
# Subcommands:
#   issue <domain>     Issue cert if missing
#   issue-all          Issue certs for every domain in domain-list.txt
#   copy <domain>      Mirror live cert into /etc/haproxy/certs; print crt-list line
#   copy-all           Mirror all certs, regenerate crt-list, reload HAProxy
#   bootstrap          ensure config + issue-all + copy-all (first boot)
#   reload             ensure config + systemctl try-reload-or-restart haproxy

set -euo pipefail

ENSURE_CONFIG="/usr/local/sbin/ensure-haproxy-config.sh"
LEGO="/usr/local/sbin/lego-haproxy-launch.sh"
LEGO_PATH="/etc/haproxy/lego"
ACME_EMAIL='rsvalerio+certs@gmail.com'
ACME_SERVER='https://acme-v02.api.letsencrypt.org/directory'
RENEW_DAYS='30'
LEGO_EXTRA=''

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$*" >&2; }
die() { log "ERROR: $*"; exit 1; }

_TMP=""
_cleanup() {
  if [[ -n "$_TMP" && -e "$_TMP" ]]; then
    rm -f "$_TMP"
  fi
}
trap _cleanup EXIT

require_cmd() { command -v "$1" >/dev/null 2>&1 || die "missing command: $1"; }

read_domains() {
  local file="$1" raw line
  [[ -f "$file" ]] || return 0
  while IFS= read -r raw || [[ -n "$raw" ]]; do
    line="${raw#"${raw%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [[ -z "$line" || "$line" =~ ^# ]] && continue
    printf '%s\n' "${line%%[[:space:]]*}"
  done < "$file"
}

crt_list_entry() {
  local domain="$1"
  printf '/etc/haproxy/certs/%s/site.pem\n' "$domain"
}

lego_server_args() {
  if [[ -n "${ACME_SERVER// }" ]]; then
    printf '%s ' --server "$ACME_SERVER"
  fi
}

# Global flags must precede the subcommand: lego [global options] run|renew ...
lego_issue() {
  local domain="${1:?}"
  # shellcheck disable=SC2086
  "$LEGO" \
    --accept-tos \
    --email "$ACME_EMAIL" \
    --dns cloudflare \
    --path "$LEGO_PATH" \
    $(lego_server_args) \
    $LEGO_EXTRA \
    --domains "$domain" \
    run
}

lego_renew() {
  local domain="${1:?}"
  # shellcheck disable=SC2086
  "$LEGO" \
    --accept-tos \
    --email "$ACME_EMAIL" \
    --dns cloudflare \
    --path "$LEGO_PATH" \
    $(lego_server_args) \
    $LEGO_EXTRA \
    --domains "$domain" \
    renew --days "$RENEW_DAYS"
}

issue_one() {
  local domain="${1:?usage: issue <domain>}"
  [[ -n "${ACME_EMAIL// }" ]] || die "ACME_EMAIL is not set"
  require_cmd "$LEGO"
  local cert_dir="${LEGO_PATH}/certificates"
  if [[ -f "${cert_dir}/${domain}.crt" && -f "${cert_dir}/${domain}.key" ]]; then
    log "issue: ${domain} already present, skipping"
    return 0
  fi
  log "issue: ${domain}"
  install -d -m 0750 "$LEGO_PATH" "$cert_dir"
  lego_issue "$domain"
}

issue_all() {
  local list=/etc/haproxy/certs/domain-list.txt
  [[ -f "$list" ]] || { log "issue-all: no $list, nothing to do"; return 0; }
  while IFS= read -r domain; do
    issue_one "$domain"
  done < <(read_domains "$list")
}

copy_one() {
  local domain="${1:?usage: copy <domain>}"
  local src="${LEGO_PATH}/certificates/${domain}"
  if [[ ! -f "${src}.crt" || ! -f "${src}.key" ]]; then
    log "copy: ${domain} skipped (no PEMs at ${src}.{crt,key})"
    return 0
  fi
  install -d -m 0750 "/etc/haproxy/certs/${domain}"
  install -m 0644 "${src}.crt" "/etc/haproxy/certs/${domain}/site.pem"
  install -m 0640 "${src}.key" "/etc/haproxy/certs/${domain}/site.pem.key"
  crt_list_entry "$domain"
}

ensure_haproxy_config() {
  require_cmd "$ENSURE_CONFIG"
  log "ensure: regenerate (if needed) and validate haproxy.cfg"
  "$ENSURE_CONFIG"
}

copy_all() {
  local list=/etc/haproxy/certs/domain-list.txt
  local crt_list=/etc/haproxy/certs/crt-list.txt
  if [[ ! -f "$list" ]]; then
    log "copy-all: no $list, nothing to do"
    return 0
  fi
  install -d -m 0750 /etc/haproxy/certs
  _TMP="$(mktemp)"
  while IFS= read -r domain; do
    copy_one "$domain" >> "$_TMP" || true
  done < <(read_domains "$list")
  if [[ ! -s "$_TMP" ]]; then
    log "copy-all: no certs available yet, $crt_list left untouched"
    return 0
  fi
  install -m 0644 "$_TMP" "$crt_list"
  log "copy-all: wrote $crt_list"
  if [[ -f /etc/haproxy/haproxy-sites.json ]]; then
    log "copy-all: regenerate haproxy.cfg for TLS bind"
    /usr/local/sbin/gen-haproxy-config.sh config
  fi
  reload_haproxy
}

reload_haproxy() {
  ensure_haproxy_config
  log "reload: systemctl try-reload-or-restart haproxy"
  systemctl try-reload-or-restart haproxy
}

renew_one() {
  local domain="${1:?usage: renew <domain>}"
  [[ -n "${ACME_EMAIL// }" ]] || die "ACME_EMAIL is not set"
  require_cmd "$LEGO"
  local cert_dir="${LEGO_PATH}/certificates"
  if [[ ! -f "${cert_dir}/${domain}.crt" || ! -f "${cert_dir}/${domain}.key" ]]; then
    log "renew: ${domain} missing, issuing instead"
    issue_one "$domain"
    return
  fi
  log "renew: ${domain}"
  lego_renew "$domain"
}

renew() {
  local list=/etc/haproxy/certs/domain-list.txt
  require_cmd "$LEGO"
  log "renew: lego renew --days=${RENEW_DAYS} (path=${LEGO_PATH})"
  install -d -m 0750 "$LEGO_PATH" "${LEGO_PATH}/certificates"
  [[ -f "$list" ]] || { log "renew: no $list, nothing to do"; return 0; }
  while IFS= read -r domain; do
    renew_one "$domain"
  done < <(read_domains "$list")
  copy_all
}

bootstrap() {
  # Generate domain-list + cfg before issuance; validate only after copy_all reload.
  if [[ -f /etc/haproxy/haproxy-sites.json ]]; then
    log "bootstrap: generate domain-list and haproxy.cfg"
    /usr/local/sbin/gen-haproxy-config.sh all
  fi
  issue_all
  copy_all
}

usage() {
  cat <<EOF
Usage: ${0##*/} <command> [args]

Commands:
  issue <domain>      Issue cert via lego (DNS-01) if missing
  issue-all           Issue certs for every domain in /etc/haproxy/certs/domain-list.txt
  copy <domain>       Mirror live cert into /etc/haproxy/certs; print crt-list entry
  copy-all            Mirror all certs, regenerate /etc/haproxy/certs/crt-list.txt, reload HAProxy
  bootstrap           issue-all + copy-all (first boot)
  renew               lego renew --days + copy-all (used by lego-haproxy.timer)
  renew-hook          Alias of copy-all (e.g. lego hook)
  reload              systemctl try-reload-or-restart haproxy
  help                Show this help
EOF
}

main() {
  local cmd="${1:-help}"
  shift || true
  case "$cmd" in
    issue)        issue_one "${1:-}" ;;
    issue-all)    issue_all ;;
    copy)         copy_one "${1:-}" ;;
    copy-all)     copy_all ;;
    bootstrap)    bootstrap ;;
    renew)        renew ;;
    renew-hook)   copy_all ;;
    reload)       reload_haproxy ;;
    help|-h|--help) usage ;;
    *) usage; die "unknown command: $cmd" ;;
  esac
}

main "$@"

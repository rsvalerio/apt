#!/bin/bash
# Resolves Cloudflare DNS API token at start via OCI instance principal (see /usr/local/bin/get_secret).
set -euo pipefail
export CF_DNS_API_TOKEN="$(/usr/local/bin/get_secret vm1-cf-token)"
exec /usr/bin/lego "$@"

#!/usr/bin/env bash
# origin-cert-haproxy.sh
#
# Install Cloudflare Origin CA certificates (15y) from OCI Vault into
# HAProxy's crt-list, then regenerate haproxy.cfg and reload.
#
# Cert/key are created manually (Cloudflare dashboard → SSL/TLS → Origin
# Server) and written out-of-band into OCI Vault secrets; this script only
# reads them on the VM via get_secret (instance principal).
#
# Zones: one per line in /etc/haproxy/origin-zones.txt (my-haproxy-sites).
# Secret names: vm1-origin-<zone with '.'→'-'-cert / -key (get_secret only
# allows vm1-[a-z0-9-]+).
#
# Layout per zone matches the lego flow so crt-list / generate_tls_bind in
# gen-haproxy-config.sh keep working: /etc/haproxy/certs/<zone>/{site.pem,site.pem.key}.
#
# Subcommands:
#   install   Fetch + install every zone's cert, rewrite crt-list, reload (default)
#   help      Show this help

set -euo pipefail

GET_SECRET="/usr/local/bin/get_secret"
ENSURE_CONFIG="/usr/local/sbin/ensure-haproxy-config.sh"
CERTS_DIR="/etc/haproxy/certs"
CRT_LIST="${CERTS_DIR}/crt-list.txt"
ZONES_FILE="/etc/haproxy/origin-zones.txt"

log() { printf '[%s] %s\n' "$(date -u +%FT%TZ)" "$*" >&2; }

read_zones() {
  local file="$1" raw line
  [[ -f "$file" ]] || return 0
  while IFS= read -r raw || [[ -n "$raw" ]]; do
    line="${raw#"${raw%%[![:space:]]*}"}"
    line="${line%"${line##*[![:space:]]}"}"
    [[ -z "$line" || "$line" =~ ^# ]] && continue
    printf '%s\n' "$line"
  done < "$file"
}

install_zone() {
  local zone="$1" dashed="${1//./-}" cert key dir
  # Fetch fails soft: a zone that already has certs on disk keeps serving
  # through transient Vault errors (crt-list entries are emitted from disk).
  cert="$("$GET_SECRET" "vm1-origin-${dashed}-cert")" || return 1
  key="$("$GET_SECRET" "vm1-origin-${dashed}-key")" || return 1
  if [[ "$cert" != *"BEGIN CERTIFICATE"* || "$key" != *"PRIVATE KEY"* ]]; then
    log "install: ${zone} payload is not PEM, skipping"
    return 1
  fi
  dir="${CERTS_DIR}/${zone}"
  install -d -m 0750 "$dir"
  # Stage + atomic rename so a failed fetch/parse never leaves half-written PEMs.
  printf '%s\n' "$cert" > "${dir}/site.pem.new"
  printf '%s\n' "$key" > "${dir}/site.pem.key.new"
  if ! openssl x509 -in "${dir}/site.pem.new" -noout >/dev/null 2>&1; then
    rm -f "${dir}/site.pem.new" "${dir}/site.pem.key.new"
    log "install: ${zone} certificate does not parse, skipping"
    return 1
  fi
  mv "${dir}/site.pem.new" "${dir}/site.pem"
  mv "${dir}/site.pem.key.new" "${dir}/site.pem.key"
  chown haproxy:haproxy "${dir}/site.pem" "${dir}/site.pem.key" 2>/dev/null || true
  chmod 0644 "${dir}/site.pem"
  chmod 0640 "${dir}/site.pem.key"
  log "install: ${zone}"
}

install_all() {
  local zone tmp rc=0
  if [[ ! -f "$ZONES_FILE" ]]; then
    log "install: no $ZONES_FILE, nothing to do"
    return 0
  fi
  tmp="$(mktemp)"
  while IFS= read -r zone; do
    install_zone "$zone" || rc=1
    if [[ -f "${CERTS_DIR}/${zone}/site.pem" ]]; then
      printf '%s/%s/site.pem\n' "$CERTS_DIR" "$zone" >> "$tmp"
    fi
  done < <(read_zones "$ZONES_FILE")
  if [[ -s "$tmp" ]]; then
    install -m 0644 "$tmp" "$CRT_LIST"
    log "install: wrote $CRT_LIST"
  else
    log "install: no certs available yet, $CRT_LIST left untouched"
  fi
  rm -f "$tmp"
  return "$rc"
}

usage() {
  cat <<EOF
Usage: ${0##*/} [install]

Commands:
  install   Fetch origin certs from OCI Vault, rewrite crt-list, reload HAProxy (default)
  help      Show this help
EOF
}

main() {
  local cmd="${1:-install}"
  shift || true
  case "$cmd" in
    install)
      # A failed zone must not skip the regen + reload for the zones that
      # did install — finish the run, then surface the failure via exit code.
      rc=0
      install_all || rc=$?
      "$ENSURE_CONFIG"
      log "reload: systemctl try-reload-or-restart haproxy"
      systemctl try-reload-or-restart haproxy
      exit "$rc"
      ;;
    help|-h|--help) usage ;;
    *) usage; log "unknown command: $cmd"; exit 1 ;;
  esac
}

main "$@"

#!/usr/bin/env bash
# Generate HAProxy haproxy.cfg and domain-list.txt from haproxy-sites.json.
#
# Template: haproxy.cfg in this directory (__HAPROXY_*__ tokens).
# JSON shape matches /etc/haproxy/haproxy-sites.json (oci-vm1 cloud-init).
#
# Usage:
#   gen-haproxy-config.sh [domain-list|config|all]
#
# Override paths for local testing:
#   HAPROXY_SITES_JSON=test/fixtures/haproxy-sites.json \
#   HAPROXY_CONFIG=/tmp/haproxy.cfg \
#   HAPROXY_DOMAIN_LIST=/tmp/domain-list.txt \
#   ./src/gen-haproxy-config.sh all
set -euo pipefail

script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

if [[ -f "${script_dir}/haproxy.cfg" ]]; then
  _default_cfg_template="${script_dir}/haproxy.cfg"
else
  _default_cfg_template="/usr/share/my-haproxy/haproxy.cfg"
fi

haproxy_sites_json="${HAPROXY_SITES_JSON:-/etc/haproxy/haproxy-sites.json}"
haproxy_cfg_template="${HAPROXY_CFG_TEMPLATE:-${_default_cfg_template}}"
haproxy_config="${HAPROXY_CONFIG:-/etc/haproxy/haproxy.cfg}"
haproxy_domain_list="${HAPROXY_DOMAIN_LIST:-/etc/haproxy/certs/domain-list.txt}"

generate_domain_list() {
  jq -r '.zone as $z | $z, "www.\($z)",(.sites[] | "\(.name).\($z)")' \
    < "$haproxy_sites_json" > "$haproxy_domain_list"
}

generate_frontend_acls() {
  # host_only strips an explicit port — gRPC clients send :authority as host:443.
  jq -r '.zone as $z | .sites[] | "    acl host_\(.name) hdr(host),host_only -i \(.name).\($z)"' \
    < "$haproxy_sites_json"
}

generate_frontend_use_backend() {
  jq -r '.sites[] | "    use_backend backend_\(.name) if host_\(.name)"' \
    < "$haproxy_sites_json"
}

generate_backend() {
  # h2: true => gRPC backend (h2c upstream); needs proto h2 on the server line
  # and timeouts above the gRPC long-poll interval (Temporal workers poll ~70s).
  jq -r '.sites[] |
    "backend backend_\(.name)\(if .h2 then "\n    timeout server 120s\n    timeout tunnel 120s" else "" end)\n    server \(.name) \(.backend)\(if .proxy_protocol then " send-proxy" else "" end)\(if .h2 then " proto h2" else "" end)\n"
  ' < "$haproxy_sites_json"
}

generate_tls_bind() {
  local crt_list=/etc/haproxy/certs/crt-list.txt
  if [[ -f "$crt_list" && -s "$crt_list" ]]; then
    printf '    bind *:443 ssl crt-list %s alpn h2,http/1.1\n' "$crt_list"
  else
    printf '    # bind *:443 ssl crt-list %s (run lego-haproxy.sh bootstrap when certs are ready)\n' \
      "$crt_list"
  fi
}

generate_config() {
  local zone
  zone=$(jq -r '.zone' < "$haproxy_sites_json")

  {
    while IFS= read -r line || [[ -n "$line" ]]; do
      case "$line" in
        *__HAPROXY_DOMAIN_ZONE__*)
          printf '%s\n' "${line//__HAPROXY_DOMAIN_ZONE__/$zone}"
          ;;
        *__HAPROXY_TLS_BIND__*)
          generate_tls_bind
          ;;
        *__HAPROXY_FRONTEND_ACLS__*)
          generate_frontend_acls
          ;;
        *__HAPROXY_FRONTEND_USE_BACKEND__*)
          generate_frontend_use_backend
          ;;
        *__HAPROXY_BACKENDS__*)
          generate_backend
          ;;
        *)
          printf '%s\n' "$line"
          ;;
      esac
    done < "$haproxy_cfg_template"
  } > "$haproxy_config"
}

usage() {
  cat <<EOF
Usage: ${0##*/} [domain-list|config|all]

  domain-list   Write ${haproxy_domain_list}
  config        Write ${haproxy_config}
  all           Both (default)
EOF
}

main() {
  case "${1:-all}" in
    domain-list) generate_domain_list ;;
    config) generate_config ;;
    all) generate_domain_list; generate_config ;;
    -h | --help | help) usage ;;
    *) usage >&2; exit 1 ;;
  esac
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  main "$@"
fi

#!/usr/bin/env bash
# Installs OCI CLI for get_secret via python venv + pip (no apt during postinst).
set -euo pipefail

readonly OCI=/usr/local/bin/oci
readonly INSTALL_DIR=/opt/oracle-cli

if [[ -x $OCI ]] && "$OCI" --version &>/dev/null; then
  exit 0
fi

if ! python3 -c 'import venv' 2>/dev/null; then
  echo "install-oci-cli: python3-venv required (install python3-venv)" >&2
  exit 1
fi

rm -rf "$INSTALL_DIR"
python3 -m venv "$INSTALL_DIR"
"$INSTALL_DIR/bin/pip" install --disable-pip-version-check --no-cache-dir -q oci-cli
ln -sf "$INSTALL_DIR/bin/oci" "$OCI"

[[ -x $OCI ]] || { echo "install-oci-cli: $OCI missing after install" >&2; exit 1; }

#!/bin/bash
# Resolves OpenBao runtime config at start via OCI instance principal.
set -euo pipefail

die() { echo "openbao-launch: $*" >&2; exit 1; }

# OCI Vault bundle content may include trailing newlines; trim before export.
read_secret() {
  local v
  v="$(/usr/local/bin/get_secret "$1" | tr -d '\r' | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')"
  [[ -n $v ]] || die "$1 is empty — update OCI Vault (see terraform/oci/README.md)"
  if [[ $v == PLACEHOLDER ]]; then
    die "$1 is still PLACEHOLDER — run: cd terraform/oci && terraform output openbao_ocikms_secret_values"
  fi
  printf '%s' "$v"
}

validate_ocikms() {
  local key_id=$1 crypto=$2 mgmt=$3
  [[ $key_id =~ ^ocid1\.key\. ]] \
    || die "vm1-openbao-ocikms-key-id is not a KMS key OCID (check terraform output openbao_ocikms_key_id)"
  [[ $crypto =~ ^https://.+-crypto\.kms\. ]] \
    || die "vm1-openbao-ocikms-crypto-endpoint looks wrong (check terraform output openbao_ocikms_crypto_endpoint)"
  [[ $mgmt =~ ^https://.+-management\.kms\. ]] \
    || die "vm1-openbao-ocikms-management-endpoint looks wrong (check terraform output openbao_ocikms_management_endpoint)"
}

export BAO_PG_CONNECTION_URL="$(read_secret vm1-bao-pg-connection-url)"
export VAULT_OCIKMS_SEAL_KEY_ID="$(read_secret vm1-openbao-ocikms-key-id)"
export VAULT_OCIKMS_CRYPTO_ENDPOINT="$(read_secret vm1-openbao-ocikms-crypto-endpoint)"
export VAULT_OCIKMS_MANAGEMENT_ENDPOINT="$(read_secret vm1-openbao-ocikms-management-endpoint)"
validate_ocikms "$VAULT_OCIKMS_SEAL_KEY_ID" "$VAULT_OCIKMS_CRYPTO_ENDPOINT" "$VAULT_OCIKMS_MANAGEMENT_ENDPOINT"

exec /usr/bin/bao server -config /opt/my-openbao/openbao.hcl

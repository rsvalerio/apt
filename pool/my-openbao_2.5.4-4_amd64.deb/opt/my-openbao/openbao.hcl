ui = true

storage "postgresql" {
  # BAO_PG_CONNECTION_URL is exported by openbao-launch.sh from OCI Vault.
}

seal "ocikms" {
  # VAULT_OCIKMS_* values are exported by openbao-launch.sh from OCI Vault.
}

listener "tcp" {
  address     = "127.0.0.1:8200"
  tls_disable = true
}

telemetry {
  prometheus_retention_time = "12h"
  disable_hostname          = true
}
